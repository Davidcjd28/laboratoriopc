﻿using System;
using System.ComponentModel;
using System.Security.Cryptography;

class program
{
    public program()
    {
    }

    static void Main()
    {
        Console.WriteLine("Ejercicio 1");
        string nombre = "Drako el Destructor";
        int nivel = 25;
        float puntosDeVida = 350.75f;
        bool esJefe = true;


        Console.WriteLine("Nombre: " + nombre);
        Console.WriteLine("Nivel: " + nivel);
        Console.WriteLine("Puntos de vida: " + puntosDeVida);
        Console.WriteLine("¿Es un jefe (Boss)? " + esJefe);

        Console.WriteLine("\nEjercicio 2");
        int numeroEntero = 1500;
        long numeroLargo = numeroEntero;
        double numeroDecimal = numeroLargo;
        Console.WriteLine("Valor final en double: " + numeroDecimal);

        Console.WriteLine("\nEjercicio 3");
        double precioExacto = 45.89;
        int precioRedondeado;
        precioRedondeado = (int)precioExacto;
        Console.WriteLine("precio exacto: " + precioExacto + " precio redeondado:" + precioRedondeado + "");

        Console.WriteLine("\nEjercicio 4");
        Console.WriteLine("ingresa un número");
        string entradaUsuario = Console.ReadLine();
        int numero = int.Parse(entradaUsuario);
        int resultado = numero + 5;
        Console.WriteLine("El resultado es: " + resultado);

        Console.WriteLine("\nEjercicio 5");
        string valorBooleano = "true";
        bool resultadoBooleano = Convert.ToBoolean(valorBooleano);
        string valorDecimal = "25.5";
        double resultadoDecimal = Convert.ToDouble(valorDecimal);
        Console.WriteLine("Resultado booleano: " + resultadoBooleano);
        Console.WriteLine("Resultado decimal: " + resultadoDecimal);

        Console.WriteLine("\nEjercicio 6");
        const double pi = 3.14159265;
        Console.WriteLine(pi.ToString("F2"));

        Console.WriteLine("\nEjercicio 7");
        Console.WriteLine("Ingrese el precio de un producto");
        string productoPrecioStr = Console.ReadLine();
        double productoPrecioInit = double.Parse(productoPrecioStr);
        double productoIva = productoPrecioInit * 0.21;
        double productoPrecio = productoPrecioInit + productoIva;
        Console.WriteLine("El total a pagar es: " + Convert.ToInt32(productoPrecio));
    }
}


    
    
       
   

