﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio_11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //ejercicio 1
            Console.WriteLine("Ejercicio 1");
            Console.Write("Ingrese una palabra: ");
            string palabra = Console.ReadLine();


            palabra = palabra.ToLower();

            bool esPalindromo = true;
            int longitud = palabra.Length;

            for (int i = 0; i < longitud / 2; i++)
            {
                if (palabra[i] != palabra[longitud - 1 - i])
                {
                    esPalindromo = false;
                    break;
                }
            }

            Console.WriteLine(esPalindromo);



            //ejercicio 2
            Console.WriteLine("Ejercicio 2");

            string[] espanol = { "rojo", "azul", "amarillo", "blanco", "verde" };
            string[] ingles = { "red", "blue", "yellow", "white", "green" };
            string[] italiano = { "rosso", "blu", "giallo", "bianco", "verde" };

            int opcion = 0;
            string Color;

            do
            {
                Console.WriteLine("\n--- MENÚ ---");
                Console.WriteLine("1. Practicar lección");
                Console.WriteLine("2. Terminar lección");
                Console.Write("Seleccione una opción: ");

                opcion = int.Parse(Console.ReadLine());

                if (opcion == 1)
                {
                    Console.Write("Ingrese una palabra en español: ");
                    Color = Console.ReadLine().ToLower();

                    bool encontrada = false;

                    for (int i = 0; i < espanol.Length; i++)
                    {
                        if (Color == espanol[i])
                        {
                            // Capitalizar primera letra
                            string esp = char.ToUpper(espanol[i][0]) + espanol[i].Substring(1);
                            string ing = char.ToUpper(ingles[i][0]) + ingles[i].Substring(1);
                            string ita = char.ToUpper(italiano[i][0]) + italiano[i].Substring(1);

                            Console.WriteLine($"{esp}, {ing}, {ita}");
                            encontrada = true;
                            break;
                        }
                    }

                    if (!encontrada)
                    {
                        Console.WriteLine("La palabra no corresponde a la lección actual");
                    }
                }

            } while (opcion != 2);

            Console.WriteLine("Lección finalizada.");



            //ejercicio 3
            Console.WriteLine("Ejercicio 3");

            Random rnd = new Random();
            int[] notas = new int[10];
            int opcio = 0;

            // Generar notas aleatorias entre 50 y 100
            for (int i = 0; i < notas.Length; i++)
            {
                notas[i] = rnd.Next(50, 101);
            }

            do
            {
                Console.WriteLine("\n--- MENÚ ---");
                Console.WriteLine("1. Reporte de rendimiento");
                Console.WriteLine("2. Estadísticas");
                Console.WriteLine("3. Salir");
                Console.Write("Seleccione una opción: ");
                opcion = int.Parse(Console.ReadLine());

                switch (opcion)
                {
                    case 1:
                        Console.WriteLine("\nCalificaciones:");

                        foreach (int nota in notas)
                        {
                            if (nota >= 50 && nota <= 64)
                                Console.ForegroundColor = ConsoleColor.Red;
                            else if (nota <= 79)
                                Console.ForegroundColor = ConsoleColor.Yellow;
                            else
                                Console.ForegroundColor = ConsoleColor.Green;

                            Console.Write(nota + " ");
                        }

                        Console.ResetColor();
                        Console.WriteLine();
                        break;

                    case 2:
                        int suma = 0;
                        int mayor = notas[0];
                        int menor = notas[0];

                        foreach (int nota in notas)
                        {
                            suma += nota;

                            if (nota > mayor) mayor = nota;
                            if (nota < menor) menor = nota;
                        }

                        double promedio = (double)suma / notas.Length;

                        Console.WriteLine($"Promedio: {promedio:F2}");
                        Console.WriteLine($"Nota más alta: {mayor}");
                        Console.WriteLine($"Nota más baja: {menor}");
                        break;
                }

            } while (opcion != 3);

            Console.WriteLine("Programa finalizado.");
        
    


        //ejercicio 4
            Console.WriteLine("Ejercicio 4");

            // Arreglos fijos
            string[] nombres = { "Ana", "Mario", "Saúl", "Karla", "María", "José" };
            double[] salarioPorHora = { 100, 125.50, 98.65, 125, 132.50, 102.50 };
            double[] horasLaboradas = new double[6];

            // Ingreso de horas trabajadas
            for (int i = 0; i < nombres.Length; i++)
            {
                Console.Write($"Ingrese las horas trabajadas por {nombres[i]}: ");
                horasLaboradas[i] = double.Parse(Console.ReadLine());
            }

            Console.WriteLine("\n--- PAGOS SEMANALES ---");

            // Cálculo de pagos
            for (int i = 0; i < nombres.Length; i++)
            {
                double horas = horasLaboradas[i];
                double salario = salarioPorHora[i];
                double pagoTotal;

                if (horas > 40)
                {
                    double horasExtra = horas - 40;
                    double pagoNormal = 40 * salario;
                    double pagoExtra = horasExtra * salario * 1.5;

                    pagoTotal = pagoNormal + pagoExtra;
                }
                else
                {
                    pagoTotal = horas * salario;
                }

                Console.WriteLine($"{nombres[i]}: Q{pagoTotal:F2}");
            }

            Console.WriteLine("\nCálculo finalizado.");
        }
    }
}
