﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proyecto1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //registro del sistema     //     

            string operador;
            string turno;
            Console.ForegroundColor = ConsoleColor.Cyan;    
            Console.WriteLine("_________________________");
            Console.WriteLine("  Registro del Sistema");
            Console.WriteLine("_________________________");
            Console.ResetColor();

            Console.WriteLine("ingrese su nombre");
            operador = Console.ReadLine();
            
            Console.WriteLine("ingrese su codigo de turno");
            turno = Console.ReadLine();
            
            while (turno.Length != 4) // turno debe ser de 4 caracteres 
              
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("el turno debe de ser de 4 carcactéres");
                Console.ResetColor();

                Console.WriteLine("ingrese su codigo de turno");
                turno = Console.ReadLine();
                
                }

            int capacidad;

            Console.WriteLine("ingrese la capcidad del parqueo");
            capacidad = int.Parse(Console.ReadLine());

            while (capacidad < 10) // capacidad del parqueo debe ser mayor a 10

            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("la capacidad del parqueo debe ser de mínimo 10");
                Console.ResetColor();
                Console.WriteLine("ingrese capacidad del parqueo");
                capacidad = int.Parse(Console.ReadLine());
            }



            //insiar varibles
            int ticketcreado = 0;
            int ticketcerrado = 0;
            
            
            int tiemposimuladoacumulado = 0;
            bool ticketactivo=false;

            int minutostotales=0;


            // declarar variables 
            int opcionmenu = 0;
            string placa ;
            int tipoveh = 0;
            string nombrecliente;
            int espaciosocupados = 0;
            

            DateTime horaentrada;
            DateTime horasalida;
             DateTime horaacumulada;
            int minutossimulados=0;
            TimeSpan diferencianetradasalida;
            int horastarifa = 0;
            double minutostarifa = 0;
            double tarifa=0;
            
            double fraccion = 0;
            double descuento = 0;
            double multa=0;
            string clienteVIP= "N";
            double totalrecaudado = 0;
            double totalapagar = 0;
            double totalrecargo = 0;
            int espaciosdisponibles = 0;
            //    menu interactivo   //

            Console.Clear();  // limpiar pantalla y mostrar el menu principal
            horaentrada = DateTime.Now;  // inicializamos la variable 


            do // mostrar menu principal hasta que elija salir
            {
                
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("_________________________");
                Console.WriteLine("    Parqueo SmartPark");
                Console.WriteLine("_________________________");
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine("_________________________");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("      Menu Principal");
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine("_________________________");
                Console.WriteLine("1=Crear ticket de entrada");
                Console.WriteLine("2=Registrar salida");
                Console.WriteLine("3=Ver estado del parqueo");
                Console.WriteLine("4=Simular paso del tiempo");
                Console.WriteLine("5=Salir");
                Console.WriteLine("_________________________");
                Console.ResetColor();
                opcionmenu = int.Parse(Console.ReadLine());



                switch (opcionmenu)
                {
                    case 1:
                        //-------------------------Crear Ticket ------------------------------------------------------------------
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.WriteLine("_________________________");
                        Console.WriteLine("    Crear Ticket");
                        Console.WriteLine("_________________________");
                        Console.ResetColor();

                        if (ticketactivo) //si existe ticket regresar
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("Ya existe un Ticket Activo");

                            break;
                        }
                        if (capacidad == espaciosocupados) //si parqueo esta lleno
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("parqueo lleno");
                            break;
                        }
                        Console.ResetColor();
                        Console.WriteLine("ingrese la placa");
                        placa = Console.ReadLine();


                        while (placa.Contains(" ")) //placa tiene espacios
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("La Placa tiene espacios, ingrese de nuevo");
                            Console.ResetColor();
                            Console.WriteLine(" ");
                            Console.WriteLine("ingrese la placa");
                            placa = Console.ReadLine();

                        }


                        while (placa.Length < 6 || placa.Length > 8) //placa debe tener entre 6 y 8 caracteres
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("Placa no valida");
                            Console.ResetColor();
                            Console.WriteLine(" ");
                            Console.WriteLine("ingrese la placa");
                            placa = Console.ReadLine();

                        }


                        Console.WriteLine("Ingrese nombre del cliente");
                        nombrecliente = Console.ReadLine();

                        Console.WriteLine("El cliente es VIP S=Si o N=No");
                        clienteVIP = Console.ReadLine();

                        // tipo de vehiculo
                        do //mostrar opciones hasta que seleccione una valida

                        {
                            Console.WriteLine("Ingrese tipo de vehículo");
                            Console.WriteLine("1=Moto");
                            Console.WriteLine("2=Auto");
                            Console.WriteLine("3=Pickup/suv");
                            tipoveh = int.Parse(Console.ReadLine());
                        }
                        while (tipoveh < 1 || tipoveh > 3); // tipo de vehiculo

                        ticketactivo = true;
                        espaciosocupados = espaciosocupados + 1;
                        ticketcreado = ticketcreado + 1;

                        horaentrada = DateTime.Now;  // guardamos la hora de ingreso


                        Console.WriteLine(" ");
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("Ticket Creado");
                        Console.ResetColor();
                        Console.WriteLine("presione enter para continuar");
                        Console.ReadLine();


                        Console.Clear(); //limpiamos la pantalla despues de cada opcion del menu


                        break;
                    case 2:
                        //---------------------------Salida del Vehiculo ---------------------------------------------------------------
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.WriteLine("_________________________");
                        Console.WriteLine("    Registrar Salida");
                        Console.WriteLine("_________________________");
                        Console.ResetColor();

                        if (ticketactivo == false) //si no existe ticket regresar
                        {

                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("no existe ticket activo");
                            Console.ResetColor();
                            Console.WriteLine("presione enter para continuar");
                            Console.ReadLine();
                            Console.Clear();
                            break;
                        }

                        if (minutossimulados > 0) //agregamos los minutos simulados si existen
                        {
                            horasalida = DateTime.Now.AddMinutes(minutossimulados);
                        }
                        else
                        {
                            horasalida = DateTime.Now;
                        }

                        diferencianetradasalida = horasalida - horaentrada;
                        minutostotales = Convert.ToInt32(diferencianetradasalida.TotalMinutes);


                        //calcular horas y minutos parqueado
                        horastarifa = minutostotales / 60;
                        minutostarifa = minutostotales - (horastarifa * 60);


                        switch (tipoveh)
                        {
                            case 1://moto
                                tarifa = horastarifa * 5;
                                if (minutostarifa > 15)  //se cobra fraccion
                                {
                                    fraccion = 5;
                                }
                                break;
                            case 2:
                                tarifa = horastarifa * 10;
                                if (minutostarifa > 15)  //se cobra fraccion
                                {
                                    fraccion = 10;
                                }
                                break;
                            case 3:
                                tarifa = horastarifa * 15;
                                if (minutostarifa > 15)  //se cobra fraccion
                                {
                                    fraccion = 15;
                                }
                                break;

                        }

                        if (horastarifa > 6)//Se cobra multa fija si se pasa de 6 horas
                        {
                            multa = 25;
                        }
                        if (clienteVIP == "S" || clienteVIP == "s")//verificamos si es cliente VIP
                        {
                            descuento = (tarifa + fraccion + multa) * 0.1;  //10% de descuento
                        }
                        if (horastarifa > 6)//Se calcula el recargo si aplica
                        {
                            totalrecargo = (tarifa + fraccion + multa - descuento) * 0.2; //20% de recargo
                        }

                        totalapagar = (tarifa + fraccion + multa - descuento + totalrecargo);

                        Console.WriteLine("Minutos Totales : " + minutostotales);
                        Console.WriteLine(horastarifa + " horas y  " + minutostarifa + " minutos");


                        Console.WriteLine(" ");
                        Console.WriteLine("Total a pagar : ");
                        Console.WriteLine(" ");
                        Console.WriteLine("+ Tarifa Horas: " + tarifa);
                        Console.WriteLine("+ Tarifa Fracción: " + fraccion);
                        if (multa > 0) { 
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.WriteLine("+ Multa: " + multa + " Por pasarse de 6 horas");
                        Console.ResetColor();
                                    }
                        Console.WriteLine("- Descuento: " + descuento);
                        Console.WriteLine(" ");
                        if (totalrecargo > 0) //mostramos si se cobro recargo
                        {
                            Console.ForegroundColor = ConsoleColor.Blue;
                            Console.WriteLine("+ 20% de Recargo por Permanencia Extrema: " + totalrecargo);
                            Console.WriteLine(" ");
                            Console.ResetColor();
                        }
                        Console.ForegroundColor = ConsoleColor.Green ;
                        Console.WriteLine("Monto Total a pagar : " + totalapagar);
                        Console.ResetColor  ();

                        Console.WriteLine(" ");
                        Console.WriteLine("presione enter  para continuar");
                        Console.ReadLine();
                        Console.Clear();


                        espaciosocupados = espaciosocupados - 1;

                        totalrecaudado = totalrecaudado + totalapagar;
                        ticketcerrado = ticketcerrado + 1;
                        ticketactivo = false;
                        
                        break;
                    case 3:
                        //------------------------Estado del parqueo -------------------------------------------------------------------
                        Console.Clear();
                        
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.WriteLine("_________________________");
                        Console.WriteLine("   Estado del Parqueo");
                        Console.WriteLine("_________________________");
                        Console.ForegroundColor = ConsoleColor.Magenta;
                        Console.WriteLine("Capacidad total del parque "+capacidad);
                        Console.WriteLine("espacios ocupados del parque " + espaciosocupados);
                        espaciosdisponibles = capacidad - espaciosocupados;
                        Console.WriteLine("espacios disponibles " + espaciosdisponibles);
                        Console.WriteLine("tiempo simulado " +  tiemposimuladoacumulado);
                        Console.WriteLine("total recaudado " + totalrecaudado);
                        Console.WriteLine("tickets creados " + ticketcreado);
                        Console.WriteLine("tickets cerrados " + ticketcerrado);
                        Console.ResetColor();
                        

                        Console.WriteLine(" ");
                        Console.WriteLine("presione enter  para continuar");
                        Console.ReadLine();
                        Console.Clear();

                        break;

                    case 4:
                        //------------------------Simular tiempo -------------------------------------------------------------------
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.WriteLine("_________________________");
                        Console.WriteLine(" Simular paso del Tiempo");
                        Console.WriteLine("_________________________");
                        Console.ResetColor();

                        if (ticketactivo == false) //si no existe ticket no se puede simuilar
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("no existe ticket activo, cree primero el ticket");
                            Console.ResetColor();
                            Console.WriteLine("presione enter para continuar");
                            Console.ReadLine();

                            break;
                        }


                        Console.WriteLine("ingrese minutos");
                        minutossimulados=int.Parse(Console.ReadLine());

                        while (minutossimulados <1 || minutossimulados>1440) // el tiempo simulado solo de 1 a 1440

                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("la cantidad de minutos solo puede ser de 1 a 14040");
                            Console.ResetColor();
                            Console.WriteLine("ingrese minutos");
                            minutossimulados = int.Parse(Console.ReadLine());
                        }


                        horasalida = DateTime.Now.AddMinutes(minutossimulados);

             
                        diferencianetradasalida = horasalida - horaentrada;

                        minutostotales = Convert.ToInt32(diferencianetradasalida.TotalMinutes);


                        //calcular horas y minutos parqueado
                        horastarifa = minutostotales / 60;
                        minutostarifa = minutostotales - (horastarifa * 60);
                        if (horastarifa > 6)
                        {
                            Console.WriteLine(" ");
                            Console.ForegroundColor = ConsoleColor.Yellow;
                            Console.WriteLine("Multa próxima a cobrar por pasar 6 horas");
                            Console.WriteLine(" ");
                        }
                        if (horastarifa > 12)
                        {
                            Console.ForegroundColor = ConsoleColor.Yellow;
                            Console.WriteLine("Se cobrara recargo por permanencia extrema, más de 12 horas");
                            Console.WriteLine(" ");
                        }
                        Console.ResetColor();

                        //horaacumulada = horaentrada.AddMinutes(minutossimulados);
                        tiemposimuladoacumulado = tiemposimuladoacumulado + minutossimulados;

                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("El tiempo acumulado es : " );
                        Console.WriteLine(horastarifa   + " Horas, " + minutostarifa + " minutos");


                        Console.WriteLine(" ");
                        Console.ResetColor ();  
                        Console.WriteLine("presione enter para continuar");
                        Console.ReadLine();
                        Console.Clear();
                    
                        break;


                    case 5: // ------------------------ Salir ------------------------------------------ 

                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.WriteLine("_________________________");
                        Console.WriteLine("    Resumen de turno");
                        Console.WriteLine("_________________________");
                        Console.ForegroundColor = ConsoleColor.Magenta;
                        Console.WriteLine("Espacios ocupados del parque " + espaciosocupados);
                        espaciosdisponibles = capacidad - espaciosocupados;
                        Console.WriteLine("Tiempo simulado " + tiemposimuladoacumulado);
                        Console.WriteLine("Tickets creados " + ticketcreado);
                        Console.WriteLine("Tickets cerrados " + ticketcerrado);
                        Console.WriteLine(" " );
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("El total recaudado " + totalrecaudado);

                        Console.ResetColor();


                        Console.WriteLine(" ");
                        Console.WriteLine("presione enter  para continuar");
                        Console.ReadLine();
                        Console.Clear();
                        break;
                    default:
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("opcion no reconocida");
                        Console.ResetColor();
                        break;


                }

            } while (opcionmenu != 5);
        }
    }
}
