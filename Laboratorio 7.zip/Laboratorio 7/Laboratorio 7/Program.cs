﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio_7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("ejercicio 1");
            string nombre = "Carlos Orozco";
            int carnet = 1059426;
            int indice = 1;
            Console.WriteLine("Nombre: " + nombre + " Carnet:" + carnet.ToString());
           
            while (indice <= 20) {
                if (indice % 2 == 0) {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                }
                else { Console.ForegroundColor = ConsoleColor.Green; }
                Console.WriteLine(indice);
                indice=indice + 1;
                
            }
            Console.ForegroundColor = ConsoleColor.White;
            Console.ReadLine();

            Console.WriteLine("ejercicio 2");
            int numero;

            Console.Write("Ingrese un número entero positivo: ");
            numero = int.Parse(Console.ReadLine());

            if (numero <= 0)
            {
                Console.WriteLine("El número debe ser positivo.");
                return;
            }

            int i = 1;

            Console.WriteLine("Divisores positivos de " + numero + ":");

            do
            {
                if (numero % i == 0)
                {
                    Console.WriteLine(i);
                }

                i=i+1;

            } while (i <= numero);

            int numero1;
            

            Console.WriteLine("ejercicio 3");
            Console.Write("Ingrese un número: ");
            int n = int.Parse(Console.ReadLine());

            int a = 0;
            int b = 1;

            for (i = 1; i <= n; i=i+1)
            {
                Console.Write(a + " ");
                int c = a + b;
                a = b;
                b = c;
            }

            Console.WriteLine("ejercicio 4");
            int resultado;
            for (i = 1; i <= 12; i = i + 1)
            {
             Console.WriteLine("TABLA DEL: "+i);
                for (int e = 1; e <= 10; e = e + 1)
                {
                  resultado = i * e;
                    Console.WriteLine(i+" X " + e+" = "+resultado);
                }
            }
        }
}
}
