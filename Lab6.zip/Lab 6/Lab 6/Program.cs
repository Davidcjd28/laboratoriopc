﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Laboratorio_6
{
    internal class Program

    {
        static void Main(string[] args)
        {


            Console.Write("¿Cómo te llamas? ");
            string nombre = Console.ReadLine();
            Console.WriteLine("Hola, " + nombre + " ¡Bienvenido a C#!");

            //Ejercicio 1

            Console.WriteLine(" ");
            Console.WriteLine(" ");
            Console.WriteLine("Ejercio 1");
            Console.WriteLine(" ");


            Console.WriteLine("Ingrese la temperatura a convertir ");

            double temperatura = double.Parse(Console.ReadLine());

            Console.WriteLine("A qué temperatura desea convertir ");
            Console.WriteLine("1 - De Celsius a Fahrenheit ");
            Console.WriteLine("2 - De Fahrenheit a Celsius  ");
            Console.WriteLine("3 - De Celsius a Kelvin ");

            Console.Write("Opción : ");
            int opcion = int.Parse(Console.ReadLine());


            double resultado;


            switch (opcion)
            {
                case 1:
                    resultado = (temperatura * 9 / 5) + 32;
                    Console.Write("Temperatura en Fahrenheit es: " + resultado);
                    break;
                case 2:
                    resultado = (temperatura - 32) * 5 / 9;
                    Console.Write("Temperatura en Celsius es: " + resultado);
                    break;
                case 3:
                    resultado = (temperatura - 273.15);
                    Console.Write("Temperatura en Kelvin es: " + resultado);
                    break;

                default:
                    Console.Write("Opción no valida  ");
                    break;
            }

            //Ejercicio 2

            Console.WriteLine(" ");
            Console.WriteLine(" ");
            Console.WriteLine("Ejercio 2");
            Console.WriteLine(" ");


            Console.WriteLine("Ingrese cantidad de unidades compradas ");

            int unidades = int.Parse(Console.ReadLine());

            Console.WriteLine("Qué tipo de cliente es ");
            Console.WriteLine("1 - Regular ");
            Console.WriteLine("2 - VIP  ");

            Console.Write("Opción : ");
            int opcion2 = int.Parse(Console.ReadLine());


            switch (opcion2)
            {
                case 1:
                    if (unidades > 100)
                        Console.Write("Descuento del 15% mayorista ");
                    else
                        Console.Write("Descuento del 5% cliete regular ");
                    break;
                case 2:
                    if (unidades > 100)
                        Console.Write("Descuento del 15% mayorista ");
                    else
                        Console.Write("Descuento del 10% cliete VIP ");
                    break;

                default:
                    Console.Write("Opción no valida  ");
                    break;
            }


            //Ejercicio 3

            Console.WriteLine(" ");
            Console.WriteLine(" ");
            Console.WriteLine("Ejercio 3");
            Console.WriteLine(" ");

            Console.WriteLine("Ingrese cantidad de horas ");

            int horas = int.Parse(Console.ReadLine());
            int montopagar;

            if (horas < 2)
            {
                montopagar = horas * 5;
                Console.Write("Monto a pagar es : " + montopagar);
            }
            else
                if (horas >= 2 & horas <= 5)
                {
                    montopagar = horas * 4;
                    Console.Write("Monto a pagar es : " + montopagar);
                }
                else
                {
                    montopagar = horas * 3;
                    Console.Write("Monto a pagar es : " + montopagar);
                }


            //Ejercicio 4


            Console.WriteLine(" ");
            Console.WriteLine(" ");
            Console.WriteLine("Ejercio 4");
            Console.WriteLine(" ");

            Console.WriteLine("ingrese cual fue su nivel de rendimiento 0.00, 0.4 , 0.6 o más");

            double rendimiento = double.Parse(Console.ReadLine());

            double dinero_recibir = 2400 * rendimiento;

            if ((rendimiento > 0 & rendimiento < 0.4) || (rendimiento > 0.4 & rendimiento < 0.6))

            {
                Console.WriteLine("Valor de rendimiento no es valido " + rendimiento);

            }
            else { 
                   Console.Write("Total de dinero a recibir es : " + dinero_recibir);

                }

        }
    }
}  