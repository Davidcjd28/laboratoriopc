﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Persona
            Persona p = new Persona();
            p.nombre = "Juan";
            p.edad = 20;
            p.altura = 1.75;
            p.estudiante = true;

            Console.WriteLine("Persona:");
            Console.WriteLine(p.nombre + ", " + p.edad + ", " + p.altura + ", " + p.estudiante);

            //Vehiculo
            Vehiculo v = new Vehiculo();
            v.marca = "Toyota";
            v.modelo = "Corolla";
            v.anio = 2020;
            v.color = "Rojo";
            v.placa = "P123ABC";

            Console.WriteLine("\nVehiculo:");
            Console.WriteLine(v.marca + ", " + v.modelo + ", " + v.anio + ", " + v.color + ", " + v.placa);

            //Producto (2 objetos)
            Producto prod1 = new Producto();
            prod1.codigo = "001";
            prod1.nombre = "Laptop";
            prod1.precio = 800;
            prod1.stock = 5;
            prod1.disponible = true;

            Producto prod2 = new Producto();
            prod2.codigo = "002";
            prod2.nombre = "Mouse";
            prod2.precio = 20;
            prod2.stock = 50;
            prod2.disponible = true;

            Console.WriteLine("\nProductos:");
            Console.WriteLine(prod1.nombre + " - $" + prod1.precio);
            Console.WriteLine(prod2.nombre + " - $" + prod2.precio);

            //Mascota
            Mascota m = new Mascota();
            m.nombre = "Max";
            m.especie = "Perro";
            m.edad = 3;
            m.peso = 12.5;
            m.vacunado = true;

            Console.WriteLine("\nMascota:");
            Console.WriteLine(m.nombre + ", " + m.especie + ", " + m.edad + ", " + m.peso + ", " + m.vacunado);
        }
    }
}
