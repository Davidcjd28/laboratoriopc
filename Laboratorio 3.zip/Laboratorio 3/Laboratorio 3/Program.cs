﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nombre estudiante: ");
            string nombreestudiante = Console.ReadLine();
            Console.Write("Nombre del curso: ");
            string nombrecurso = Console.ReadLine();
            Console.WriteLine($"{nombreestudiante}, vas muy bien en el curso {nombrecurso}.");
            Console.WriteLine("\nDios te bendiga en el laboratorio!");
            Console.WriteLine("Presione una tecla para salir...");
            Console.ReadKey();
        }
    }
}
