﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio_8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 1");
            int num, mayor = 0, menor = 0;
            double suma = 0;

            for (int i = 1; i <= 20; i++)
            {
                Console.Write("Ingrese numero: ");
                num = Convert.ToInt32(Console.ReadLine());

                if (i == 1)
                {
                    mayor = num;
                    menor = num;
                }

                if (num > mayor) mayor = num;
                if (num < menor) menor = num;

                suma += num;
            }

            Console.WriteLine("Mayor: {0}", mayor);
            Console.WriteLine("Menor: {0}", menor);
            Console.WriteLine("Promedio: {0}", suma / 20);

            Console.WriteLine("Ejercicio 2");
            for (int i = 1; i <= 100; i++)
            {
                if (i % 2 == 0 && i % 7 == 0)
                    Console.WriteLine("ParSiete");
                else if (i % 2 == 0)
                    Console.WriteLine("Par");
                else if (i % 7 == 0)
                    Console.WriteLine("Siete");
                else
                    Console.WriteLine(i);
            }
            Console.WriteLine("ejercicio 3");
            double compra, total, ventas = 0;
            int descuento = 0;

            for (int i = 1; i <= 10; i++)
            {
                Console.Write("Compra del cliente: ");
                compra = Convert.ToDouble(Console.ReadLine());

                total = compra;

                if (compra > 700)
                {
                    total = compra - compra * 0.12;
                    descuento++;
                }
                else if (compra > 300)
                {
                    total = compra - compra * 0.05;
                    descuento++;
                }

                Console.WriteLine("Total a pagar: {0}", total);
                ventas += total;
            }

            Console.WriteLine("Clientes con descuento: {0}", descuento);
            Console.WriteLine("Ventas del dia: {0}", ventas);

            Console.WriteLine("ejercicio 4");
            int n, op;

            Console.Write("Ingrese numero: ");
            n = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("1. Numeros hasta 1");
            Console.WriteLine("2. Multiplos de 3");
            Console.WriteLine("3. Multiplos de 5");
            op = Convert.ToInt32(Console.ReadLine());

            if (op == 1)
            {
                for (int i = n; i >= 1; i--)
                    Console.WriteLine(i);
            }
            else if (op == 2)
            {
                for (int i = 1; i <= n; i++)
                    if (i % 3 == 0)
                        Console.WriteLine(i);
            }
            else if (op == 3)
            {
                for (int i = 1; i <= n; i++)
                    if (i % 5 == 0)
                        Console.WriteLine(i);
            }

            Console.WriteLine("Ejercicio 5");
            int filas;

            Console.Write("Ingrese el numero de filas: ");
            filas = Convert.ToInt32(Console.ReadLine());

            for (int i = 1; i <= filas; i++)
            {
                for (int j = 1; j <= i; j++)
                {
                    Console.Write("*");
                }

                Console.WriteLine();

            }
        }
    }
}