﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio_5
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Ejercicio 1");
            Console.Write("Ingresa un número: ");

            int num = int.Parse(Console.ReadLine());

            if (num > 0)
            {
                Console.WriteLine("Número positivo");
            }
            else if (num < 0)
            {
                Console.WriteLine("Número negativo");
            }
            else
            {
                Console.WriteLine("Número cero");

            }

            Console.WriteLine("Ejercicio 2");
            Console.WriteLine("Ingresa un año");
            int año = int.Parse(Console.ReadLine());
            if (año %4 ==0 && año%100!=0)//(año%400==0);
            {
                Console.WriteLine("Año bisiesto");
            }
            else
            {
                Console.WriteLine("Año natural");
            }
            Console.WriteLine("Ejercicio 3");
            Console.Write("Ingrese su ingreso mensual: ");
            double ingresoMensual = double.Parse(Console.ReadLine());

            Console.Write("¿Tiene multa? (true/false): ");
            bool multa = bool.Parse(Console.ReadLine());

            double monto = 0;

            if (ingresoMensual >= 500.01 && ingresoMensual <= 1000)
                monto = multa ? 20 : 10;

            else if (ingresoMensual <= 3000)
                monto = multa ? 30 : 15;

            else if (ingresoMensual <= 6000)
                monto = multa ? 100 : 50;

            else if (ingresoMensual <= 9000)
                monto = multa ? 150 : 75;

            else if (ingresoMensual <= 12000)
                monto = multa ? 200 : 100;

            else if (ingresoMensual > 12000)
                monto = multa ? 300 : 150;

            else
            {
                Console.WriteLine("Ingreso fuera del rango válido.");
                
            }

            Console.WriteLine("El monto a pagar por boleto de ornato es: Q " + monto);

            Console.WriteLine("Ejercicio 4");
            const int COSTO_POR_HORA = 10;

            Console.Write("Ingrese la cantidad de horas estacionado: ");
            int horas = int.Parse(Console.ReadLine());

            int totalPagar = horas * COSTO_POR_HORA;

            Console.WriteLine("Total a pagar: Q" + totalPagar);

            Console.Write("Ingrese el monto con el que realizará el pago: ");
            int montoIngresado = int.Parse(Console.ReadLine());

            if (montoIngresado < totalPagar)
            {
                Console.WriteLine("Error: El monto ingresado es menor al total a pagar.");
                return;
            }

            if (montoIngresado == totalPagar)
            {
                Console.WriteLine("Pago exacto. No se requiere cambio.");
                return;
            }

            int vuelto = montoIngresado - totalPagar;
            Console.WriteLine("Vuelto a entregar: Q" + vuelto);

            int[] billetes = { 100, 50, 20, 10, 5, 1 };

            foreach (int billete in billetes)
            {
                int cantidad = vuelto / billete;  
                vuelto = vuelto % billete;        

                if (cantidad > 0)
                {
                    Console.WriteLine("Billetes de Q" + billete + ": " + cantidad);
                }
            }

            Console.WriteLine("Gracias por utilizar la máquina de pago.");
        }
}
}
