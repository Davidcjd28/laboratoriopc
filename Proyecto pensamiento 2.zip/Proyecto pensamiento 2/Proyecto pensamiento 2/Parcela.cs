﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proyecto_2
{
    class Parcela
    {
        public Planta PlantaActual { get; set; }
        public int MesesRestantes { get; set; }

        public Parcela()
        {
            PlantaActual = null;
            MesesRestantes = 0;
        }

        public bool EstaLibre()
        {
            return PlantaActual == null;
        }

        public void Sembrar(Planta planta)
        {
            PlantaActual = planta;
            MesesRestantes = planta.MesesCrecimiento;
        }

        public bool AvanzarMes()
        {
            if (PlantaActual != null)
            {
                MesesRestantes--;

                if (MesesRestantes <= 0)
                {
                    return true;
                }
            }

            return false;
        }

        public void Limpiar()
        {
            PlantaActual = null;
            MesesRestantes = 0;
        }
    }
}
