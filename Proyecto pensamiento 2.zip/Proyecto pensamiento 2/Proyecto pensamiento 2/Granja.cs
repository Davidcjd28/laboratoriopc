﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proyecto_2
{
    class Granja
    {
        Parcela[,] parcelas;

        Planta trigo = new Planta("Trigo", 1, 100, 130);
        Planta repollo = new Planta("Repollo", 2, 180, 280);
        Planta tomate = new Planta("Tomate", 3, 250, 450);
        Planta calabaza = new Planta("Calabaza", 4, 220, 360);
        Planta esparrago = new Planta("Esparrago", 6, 500, 1000);

        int invTrigo = 0;
        int invRepollo = 0;
        int invTomate = 0;
        int invCalabaza = 0;
        int invEsparrago = 0;

        double caja;
        double capitalInicial;
        int empleados;
        double sueldo;
        int meses;

        double totalIngresos = 0;
        double totalSalarios = 0;
        double totalSemillas = 0;

        int filas;
        int columnas;

        public Granja(double dinero, int empleados, double sueldo,
                      int meses, int filas, int columnas)
        {
            this.caja = dinero;
            this.capitalInicial = dinero;
            this.empleados = empleados;
            this.sueldo = sueldo;
            this.meses = meses;
            this.filas = filas;
            this.columnas = columnas;

            parcelas = new Parcela[filas, columnas];

            for (int i = 0; i < filas; i++)
            {
                for (int j = 0; j < columnas; j++)
                {
                    parcelas[i, j] = new Parcela();
                }
            }
        }

        public void Iniciar()
        {
            int opcion;

            do
            {
                Console.Clear();

                Console.WriteLine("=================================");
                Console.WriteLine("Meses Restantes: " + meses);
                Console.WriteLine("Dinero en Caja: Q" + caja);
                Console.WriteLine("=================================");

                Console.WriteLine("1. Comprar semillas");
                Console.WriteLine("2. Sembrar");
                Console.WriteLine("3. Consultar parcelas");
                Console.WriteLine("4. Avanzar mes");
                Console.WriteLine("5. Salir");

                Console.Write("Seleccione opcion: ");
                opcion = int.Parse(Console.ReadLine());

                switch (opcion)
                {
                    case 1:
                        ComprarSemillas();
                        break;

                    case 2:
                        Sembrar();
                        break;

                    case 3:
                        ConsultarParcelas();
                        break;

                    case 4:
                        AvanzarMes();
                        break;

                    case 5:
                        ReporteFinal();
                        break;

                    default:
                        Console.WriteLine("Opcion invalida");
                        break;
                }

                if (caja <= 0 || meses <= 0)
                {
                    Console.WriteLine("\nSIMULACION FINALIZADA");
                    ReporteFinal();
                    break;
                }

                Console.WriteLine("\nPresione una tecla...");
                Console.ReadKey();

            } while (opcion != 5);
        }

        void ComprarSemillas()
        {
            double costosMensuales = empleados * sueldo;
            double utilidad = caja - costosMensuales;

            Console.WriteLine("\nCaja: Q" + caja);
            Console.WriteLine("Costos proyectados: Q" + costosMensuales);
            Console.WriteLine("Utilidad: Q" + utilidad);

            if (utilidad < 0)
            {
                Console.WriteLine("No puede comprar semillas.");
                return;
            }

            Console.WriteLine("\n1. Trigo Q100");
            Console.WriteLine("2. Repollo Q180");
            Console.WriteLine("3. Tomate Q250");
            Console.WriteLine("4. Calabaza Q220");
            Console.WriteLine("5. Esparrago Q500");

            Console.Write("Seleccione Semilla : ");
            int op = int.Parse(Console.ReadLine());

            Console.Write("Cantidad: ");
            int cantidad = int.Parse(Console.ReadLine());

            Planta seleccionada = null;

            switch (op)
            {
                case 1:
                    seleccionada = trigo;
                    break;

                case 2:
                    seleccionada = repollo;
                    break;

                case 3:
                    seleccionada = tomate;
                    break;

                case 4:
                    seleccionada = calabaza;
                    break;

                case 5:
                    seleccionada = esparrago;
                    break;
            }

            double total = seleccionada.CostoSemilla * cantidad;

            if (total > caja)
            {
                Console.WriteLine("Dinero insuficiente.");
                return;
            }



            switch (op)
            {
                case 1:
                    invTrigo += cantidad;
                    break;

                case 2:
                    invRepollo += cantidad;
                    break;

                case 3:
                    invTomate += cantidad;
                    break;

                case 4:
                    invCalabaza += cantidad;
                    break;

                case 5:
                    invEsparrago += cantidad;
                    break;
            }


            caja -= total;
            totalSemillas += total;

            Console.WriteLine("Compra realizada.");
        }

        void Sembrar()
        {
            Console.WriteLine("\nInventario:");
            Console.WriteLine("1. Trigo: " + invTrigo);
            Console.WriteLine("2. Repollo: " + invRepollo);
            Console.WriteLine("3. Tomate: " + invTomate);
            Console.WriteLine("4. Calabaza: " + invCalabaza);
            Console.WriteLine("5. Esparrago: " + invEsparrago);

            Console.Write("Fila de Parcela: ");
            int fila = int.Parse(Console.ReadLine());

            Console.Write("Columna de Parcela: ");
            int columna = int.Parse(Console.ReadLine());

            if (fila < 0 || fila >= filas ||
                columna < 0 || columna >= columnas)
            {
                Console.WriteLine("Posicion invalida.");
                return;
            }

            if (!parcelas[fila, columna].EstaLibre())
            {
                Console.WriteLine("Parcela ocupada.");
                return;
            }

            Console.Write("Tipo de semilla: ");
            int op = int.Parse(Console.ReadLine());

            switch (op)
            {
                case 1:
                    if (invTrigo > 0)
                    {
                        parcelas[fila, columna].Sembrar(trigo);
                        invTrigo--;
                        Console.WriteLine("Siembra realizada.");
                    }
                    else
                    {
                        Console.WriteLine("Semilla sin inventario.");
                    }
                    break;

                case 2:
                    if (invRepollo > 0)
                    {
                        parcelas[fila, columna].Sembrar(repollo);
                        invRepollo--;
                        Console.WriteLine("Siembra realizada.");
                    }
                    else
                    {
                        Console.WriteLine("Semilla sin inventario.");
                    }
                    break;

                case 3:
                    if (invTomate > 0)
                    {
                        parcelas[fila, columna].Sembrar(tomate);
                        invTomate--;
                        Console.WriteLine("Siembra realizada.");
                    }
                    else
                    {
                        Console.WriteLine("Semilla sin inventario.");
                    }
                    break;

                case 4:
                    if (invCalabaza > 0)
                    {
                        parcelas[fila, columna].Sembrar(calabaza);
                        invCalabaza--;
                        Console.WriteLine("Siembra realizada.");
                    }
                    else
                    {
                        Console.WriteLine("Semilla sin inventario.");
                    }
                    break;

                case 5:
                    if (invEsparrago > 0)
                    {
                        parcelas[fila, columna].Sembrar(esparrago);
                        invEsparrago--;
                        Console.WriteLine("Siembra realizada.");
                    }
                    else
                    {
                        Console.WriteLine("Semilla sin inventario.");
                    }
                    break;

                default:
                    Console.WriteLine("Opcion invalida.");
                    break;
            }

            
        }

        void ConsultarParcelas()
        {
            Console.WriteLine();

            for (int i = 0; i < filas; i++)
            {
                for (int j = 0; j < columnas; j++)
                {
                    if (parcelas[i, j].EstaLibre())
                    {
                        Console.Write("[Libre  ] ");
                    }
                    else
                    {
                        Console.Write("[Ocupada] ");
                    }
                }

                Console.WriteLine();
            }

            Console.Write("\nFila Consultar: ");
            int fila = int.Parse(Console.ReadLine());

            Console.Write("Columna Consultar: ");
            int columna = int.Parse(Console.ReadLine());


            if (fila < 0 || fila >= filas ||
                columna < 0 || columna >= columnas)
            {
                Console.WriteLine("Posicion invalida.");
                return;
            }

            Parcela p = parcelas[fila, columna];

            if (p.EstaLibre())
            {
                Console.WriteLine("Parcela libre.");
                Console.WriteLine("Ingresos esperados: Q0");
            }
            else
            {
                Console.WriteLine("Cultivo: " + p.PlantaActual.Nombre);
                Console.WriteLine("Meses crecimiento: " +
                    p.PlantaActual.MesesCrecimiento);

                Console.WriteLine("Meses restantes: " +
                    p.MesesRestantes);

                Console.WriteLine("Ingreso esperado: Q" +
                    p.PlantaActual.IngresoCosecha);
            }
        }

        void AvanzarMes()
        {
            meses--;

            double pago = empleados * sueldo;

            caja -= pago;
            totalSalarios += pago;

            Console.WriteLine("\nPago salarios: Q" + pago);

            for (int i = 0; i < filas; i++)
            {
                for (int j = 0; j < columnas; j++)
                {
                    Parcela p = parcelas[i, j];

                    if (!p.EstaLibre())
                    {
                        bool lista = p.AvanzarMes();

                        if (lista)
                        {
                            double ganancia =
                                p.PlantaActual.IngresoCosecha;

                            Console.WriteLine(
                                "Cosecha en parcela [" +
                                i + "," + j + "] -> " +
                                p.PlantaActual.Nombre +
                                " +Q" + ganancia);

                            caja += ganancia;
                            totalIngresos += ganancia;

                            p.Limpiar();
                        }
                    }
                }
            }

            Console.WriteLine("Caja actual: Q" + caja);
        }

        void ReporteFinal()
        {
            double inventarioProceso = 0;

            for (int i = 0; i < filas; i++)
            {
                for (int j = 0; j < columnas; j++)
                {
                    if (!parcelas[i, j].EstaLibre())
                    {
                        inventarioProceso +=
                            parcelas[i, j]
                            .PlantaActual
                            .IngresoCosecha;
                    }
                }
            }

            Console.WriteLine("\n========== REPORTE ==========");
            Console.WriteLine("Capital inicial: Q" + capitalInicial);
            Console.WriteLine("Ingresos: Q" + totalIngresos);
            Console.WriteLine("Inventario proceso: Q" + inventarioProceso);
            Console.WriteLine("Mano de obra: Q" + totalSalarios);
            Console.WriteLine("Materia prima: Q" + totalSemillas);
            Console.WriteLine("Utilidad final: Q" + caja);
        }
    }
}
