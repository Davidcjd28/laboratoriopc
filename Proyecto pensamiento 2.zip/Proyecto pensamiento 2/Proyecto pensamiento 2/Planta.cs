﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proyecto_2
{
    class Planta
    {
        public string Nombre { get; set; }
        public int MesesCrecimiento { get; set; }
        public double CostoSemilla { get; set; }
        public double IngresoCosecha { get; set; }

        public Planta(string nombre, int meses, double costo, double ingreso)
        {
            Nombre = nombre;
            MesesCrecimiento = meses;
            CostoSemilla = costo;
            IngresoCosecha = ingreso;
        }
    }
}
