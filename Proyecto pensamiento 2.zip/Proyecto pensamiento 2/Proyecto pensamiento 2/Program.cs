﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proyecto_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Gestion de Granja";

            Console.WriteLine("=================================");
            Console.WriteLine("   SISTEMA DE GESTION GRANJA");
            Console.WriteLine("---------------------------------");

            Console.Write("Ingrese dinero inicial: Q");
            double dineroInicial = double.Parse(Console.ReadLine());

            Console.Write("Ingrese cantidad de empleados: ");
            int empleados = int.Parse(Console.ReadLine());

            Console.Write("Ingrese sueldo mensual por empleado: Q");
            double sueldo = double.Parse(Console.ReadLine());

            Console.Write("Ingrese cantidad de meses a simular: ");
            int meses = int.Parse(Console.ReadLine());

            Console.Write("Ingrese cantidad de filas: ");
            int filas = int.Parse(Console.ReadLine());

            Console.Write("Ingrese cantidad de columnas: ");
            int columnas = int.Parse(Console.ReadLine());

            Granja granja = new Granja(
                dineroInicial,
                empleados,
                sueldo,
                meses,
                filas,
                columnas
            );

            granja.Iniciar();

            Console.ReadKey();
        }

    }
}

