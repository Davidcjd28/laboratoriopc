﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio_14
{
    
        class Producto
        {
            // Atributos
            private string nombre;
            private decimal precio;
            private int cantidad;

            // Constructor
            public Producto(string nombre, decimal precio, int cantidad)
            {
                this.nombre = nombre;
                this.precio = precio;
                this.cantidad = cantidad;
            }

            // Mostrar información
            public void MostrarInformacion()
            {
                Console.WriteLine("Producto: " + nombre);
                Console.WriteLine("Precio: Q" + precio);
                Console.WriteLine("Cantidad: " + cantidad);
            }

            // Método vender
            public void Vender(int cantidadVendida)
            {
                if (cantidad >= cantidadVendida)
                {
                    cantidad -= cantidadVendida;
                    Console.WriteLine("Venta realizada.");
                }
                else
                {
                    Console.WriteLine("No hay suficiente stock.");
                }
            }

            // Método reabastecer
            public void Reabastecer(int cantidadNueva)
            {
                cantidad += cantidadNueva;
                Console.WriteLine("Stock reabastecido.");
            }

            // Getter
            public int GetCantidad()
            {
                return cantidad;
            }
        }
    }

