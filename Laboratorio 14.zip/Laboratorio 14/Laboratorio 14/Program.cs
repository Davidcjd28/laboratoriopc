﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio_14
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("==================================");
            Console.WriteLine("EJERCICIO #1 - CUENTAS BANCARIAS");
            Console.WriteLine("==================================");

            CuentaBancaria cuenta1 = new CuentaBancaria("Juan Perez", "001", 1500);
            CuentaBancaria cuenta2 = new CuentaBancaria("Maria Lopez", "002", 3000);

            Console.WriteLine("\n--- Cuenta 1 ---");
            cuenta1.MostrarInformacion();

            Console.WriteLine("\nSaldo antes del depósito: Q" + cuenta1.GetSaldo());
            cuenta1.Depositar(500);
            Console.WriteLine("Saldo después del depósito: Q" + cuenta1.GetSaldo());

            Console.WriteLine("\nSaldo antes del retiro: Q" + cuenta1.GetSaldo());
            cuenta1.Retirar(700);
            Console.WriteLine("Saldo después del retiro: Q" + cuenta1.GetSaldo());

            Console.WriteLine("\n--- Cuenta 2 ---");
            cuenta2.MostrarInformacion();

            

            Console.WriteLine("\n==================================");
            Console.WriteLine("EJERCICIO #2 - PRODUCTOS");
            Console.WriteLine("==================================");

            Producto producto1 = new Producto("Laptop", 4500, 10);
            Producto producto2 = new Producto("Mouse", 150, 25);

            Console.WriteLine("\n--- Producto 1 ---");
            producto1.MostrarInformacion();

            Console.WriteLine("\nCantidad antes de vender: " + producto1.GetCantidad());
            producto1.Vender(3);
            Console.WriteLine("Cantidad después de vender: " + producto1.GetCantidad());

            Console.WriteLine("\nCantidad antes de reabastecer: " + producto1.GetCantidad());
            producto1.Reabastecer(5);
            Console.WriteLine("Cantidad después de reabastecer: " + producto1.GetCantidad());

            Console.WriteLine("\n--- Producto 2 ---");
            producto2.MostrarInformacion();

           

            Console.WriteLine("\n==================================");
            Console.WriteLine("EJERCICIO #3 - ESTUDIANTES");
            Console.WriteLine("==================================");

            double[] notas1 = { 80, 75, 90 };
            double[] notas2 = { 50, 60, 55 };

            Estudiante estudiante1 = new Estudiante("Carlos", 16, "5to Bach", notas1);
            Estudiante estudiante2 = new Estudiante("Ana", 17, "5to Bach", notas2);

            Console.WriteLine("\n--- Estudiante 1 ---");
            estudiante1.MostrarInformacion();
            estudiante1.Aprobar();

            Console.WriteLine("\n--- Estudiante 2 ---");
            estudiante2.MostrarInformacion();
            estudiante2.Aprobar();

            Console.WriteLine("\nAgregando nueva nota al Estudiante 2...");
            estudiante2.AgregarNota(95);

            Console.WriteLine("\n--- Información actualizada ---");
            estudiante2.MostrarInformacion();
            estudiante2.Aprobar();
        }
    }
}
