﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio_14
{
    
        class Estudiante
        {
            // Atributos
            private string nombre;
            private int edad;
            private string grado;
            private double[] notas;

            // Constructor
            public Estudiante(string nombre, int edad, string grado, double[] notas)
            {
                this.nombre = nombre;
                this.edad = edad;
                this.grado = grado;
                this.notas = notas;
            }

            // Método calcular promedio
            public double CalcularPromedio()
            {
                double suma = 0;

                for (int i = 0; i < notas.Length; i++)
                {
                    suma += notas[i];
                }

                return suma / notas.Length;
            }

            // Método mostrar información
            public void MostrarInformacion()
            {
                Console.WriteLine("Nombre: " + nombre);
                Console.WriteLine("Edad: " + edad);
                Console.WriteLine("Grado: " + grado);

                Console.Write("Notas: ");
                for (int i = 0; i < notas.Length; i++)
                {
                    Console.Write(notas[i] + " ");
                }

                Console.WriteLine();
                Console.WriteLine("Promedio: " + CalcularPromedio());
            }

            // Método aprobar
            public void Aprobar()
            {
                if (CalcularPromedio() >= 61)
                {
                    Console.WriteLine("El estudiante APROBÓ.");
                }
                else
                {
                    Console.WriteLine("El estudiante REPROBÓ.");
                }
            }

            // Método agregar nota
            public void AgregarNota(double nuevaNota)
            {
                double[] nuevasNotas = new double[notas.Length + 1];

                for (int i = 0; i < notas.Length; i++)
                {
                    nuevasNotas[i] = notas[i];
                }

                nuevasNotas[nuevasNotas.Length - 1] = nuevaNota;
                notas = nuevasNotas;

                Console.WriteLine("Nueva nota agregada.");
            }
        }
    }

