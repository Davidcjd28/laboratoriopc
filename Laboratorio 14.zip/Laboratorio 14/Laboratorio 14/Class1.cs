﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio_14
{
   
    
        class CuentaBancaria
        {
            // Atributos
            private string titular;
            private string numeroCuenta;
            private decimal saldo;

            // Constructor
            public CuentaBancaria(string titular, string numeroCuenta, decimal saldo)
            {
                this.titular = titular;
                this.numeroCuenta = numeroCuenta;
                this.saldo = saldo;
            }

            // Método para mostrar información
            public void MostrarInformacion()
            {
                Console.WriteLine("Titular: " + titular);
                Console.WriteLine("Número de cuenta: " + numeroCuenta);
                Console.WriteLine("Saldo: Q" + saldo);
            }

            // Método depositar
            public void Depositar(decimal monto)
            {
                saldo += monto;
                Console.WriteLine("Depósito realizado: Q" + monto);
            }

            // Método retirar
            public void Retirar(decimal monto)
            {
                if (saldo >= monto)
                {
                    saldo -= monto;
                    Console.WriteLine("Retiro realizado: Q" + monto);
                }
                else
                {
                    Console.WriteLine("Fondos insuficientes.");
                }
            }

            // Getter
            public decimal GetSaldo()
            {
                return saldo;
            }
        }

    }

