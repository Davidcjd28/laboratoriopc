﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("===== EJERCICIO 1 =====");
            int[,] m1 = new int[5, 5];
            LlenarMatriz(m1, 5, 5);
            Console.WriteLine("Suma diagonal principal: " + SumaDiagonalPrincipal(m1));
            Console.WriteLine("Suma diagonal secundaria: " + SumaDiagonalSecundaria(m1));

            Console.WriteLine("\n===== EJERCICIO 2 =====");
            int[,] m2 = new int[4, 6];
            LlenarMatriz(m2, 4, 6);
            Console.WriteLine("Cantidad de pares: " + ContarPares(m2));
            Console.WriteLine("Cantidad de impares: " + ContarImpares(m2));

            Console.WriteLine("\n===== EJERCICIO 3 =====");
            float[,] notas = new float[5, 4];
            IngresarNotas(notas);

            for (int i = 0; i < 5; i++)
            {
                float prom = Promedio(notas, i);
                Console.WriteLine("Estudiante " + (i + 1) + ": Promedio = " + prom +
                                  " | " + (Aprueba(prom) ? "Aprobado" : "Reprobado"));
            }

            Console.WriteLine("\n===== EJERCICIO 4 =====");
            int[,] m4 = new int[3, 3];
            LlenarMatriz(m4, 3, 3);

            if (EsSimetrica(m4))
                Console.WriteLine("La matriz es simétrica");
            else
                Console.WriteLine("La matriz no es simétrica");
        }

        // FUNCIONES GENERALES
        static void LlenarMatriz(int[,] m, int filas, int columnas)
        {
            for (int i = 0; i < filas; i++)
            {
                for (int j = 0; j < columnas; j++)
                {
                    Console.Write($"Ingrese valor [{i},{j}]: ");
                    m[i, j] = int.Parse(Console.ReadLine());
                }
            }
        }

        //EJERCICIO 1
        static int SumaDiagonalPrincipal(int[,] m)
        {
            int suma = 0;
            for (int i = 0; i < 5; i++)
            {
                suma += m[i, i];
            }
            return suma;
        }

        static int SumaDiagonalSecundaria(int[,] m)
        {
            int suma = 0;
            for (int i = 0; i < 5; i++)
            {
                suma += m[i, 4 - i];
            }
            return suma;
        }

        //EJERCICIO 2
        static int ContarPares(int[,] m)
        {
            int contador = 0;
            foreach (int num in m)
            {
                if (num % 2 == 0)
                    contador++;
            }
            return contador;
        }

        static int ContarImpares(int[,] m)
        {
            int contador = 0;
            foreach (int num in m)
            {
                if (num % 2 != 0)
                    contador++;
            }
            return contador;
        }

        //EJERCICIO 3
        static void IngresarNotas(float[,] m)
        {
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Estudiante " + (i + 1));
                for (int j = 0; j < 4; j++)
                {
                    Console.Write($"Nota {j + 1}: ");
                    m[i, j] = float.Parse(Console.ReadLine());
                }
            }
        }

        static float Promedio(float[,] m, int estudiante)
        {
            float suma = 0;
            for (int j = 0; j < 4; j++)
            {
                suma += m[estudiante, j];
            }
            return suma / 4;
        }

        static bool Aprueba(float promedio)
        {
            return promedio >= 61;
        }

        //EJERCICIO 4
        static bool EsSimetrica(int[,] m)
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (m[i, j] != m[j, i])
                        return false;
                }
            }
            return true;
        }
    }
}
