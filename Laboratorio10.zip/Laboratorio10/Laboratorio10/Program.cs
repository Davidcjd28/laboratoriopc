﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio10
{
    class Program
    {
        
    static void Main()
        {
            // ejercicio 1
            Console.WriteLine("=== Ejercicio 1: Suma de dígitos ===");

            Console.Write("Ingrese un número entero positivo: ");
            int numero = int.Parse(Console.ReadLine());

            int suma = SumarDigitos(numero);

            Console.WriteLine("La suma de los dígitos es: " + suma);


            // ejercicio 2
            Console.WriteLine("\n=== Ejercicio 2: Ajuste de saldo ===");

            Console.Write("Ingrese el saldo: ");
            double saldo = double.Parse(Console.ReadLine());

            Console.Write("Ingrese el monto a retirar: ");
            double retiro = double.Parse(Console.ReadLine());

            string mensajeSaldo = AjustarSaldo(ref saldo, retiro);

            Console.WriteLine(mensajeSaldo);
            Console.WriteLine("Saldo actual: " + saldo);


            // ejercicio 3
            Console.WriteLine("\n=== Ejercicio 3: Conversión de temperatura ===");

            Console.Write("Ingrese la temperatura en Celsius: ");
            double celsius = double.Parse(Console.ReadLine());

            double fahrenheit = 0;

            string mensajeTemp = ConvertirTemperatura(celsius, ref fahrenheit);

            Console.WriteLine(mensajeTemp);
            Console.WriteLine("Temperatura en Fahrenheit: " + fahrenheit);


            // ejercicio 4
            Console.WriteLine("\n=== Ejercicio 4: Sistema de puntos ===");

            Console.Write("Ingrese los puntos iniciales: ");
            int puntos = int.Parse(Console.ReadLine());

            puntos = AgregarPuntos(ref puntos);
            Console.WriteLine("Después de agregar puntos: " + puntos);

            puntos = QuitarPuntos(ref puntos);
            Console.WriteLine("Después de quitar puntos: " + puntos);

            string nivel = ObtenerNivel(puntos);
            string estado = EvaluarEstado(puntos);

            Console.WriteLine("Nivel: " + nivel);
            Console.WriteLine("Estado: " + estado);
        }

        // funciones 1
        static int SumarDigitos(int num)
        {
            int suma = 0;

            while (num > 0)
            {
                suma += num % 10;
                num /= 10;
            }

            return suma;
        }

        // funciones 2
        static string AjustarSaldo(ref double saldo, double retiro)
        {
            if (saldo >= retiro)
            {
                saldo -= retiro;
                return "Retiro realizado correctamente.";
            }
            else
            {
                return "Fondos insuficientes. Saldo sin cambios.";
            }
        }

        // funciones 3
        static string ConvertirTemperatura(double celsius, ref double fahrenheit)
        {
            fahrenheit = (celsius * 9 / 5) + 32;
            return "Conversión realizada correctamente.";
        }

        //funciones 4
        static int AgregarPuntos(ref int puntos)
        {
            puntos += 10;
            if (puntos > 100)
                puntos = 100;

            return puntos;
        }

        static int QuitarPuntos(ref int puntos)
        {
            puntos -= 7;
            if (puntos < 0)
                puntos = 0;

            return puntos;
        }

        static string ObtenerNivel(int puntos)
        {
            if (puntos >= 80)
                return "Avanzado";
            else if (puntos >= 50)
                return "Intermedio";
            else
                return "Básico";
        }

        static string EvaluarEstado(int puntos)
        {
            if (puntos == 100)
                return "Excelente";
            else if (puntos >= 70)
                return "Aprobado";
            else if (puntos >= 1)
                return "Reprobado";
            else
                return "Sin puntos";
        }
    }
}

