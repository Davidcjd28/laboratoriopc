﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laboratorio_9._1
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("ejercicio 1");
            Console.WriteLine("");

            Console.WriteLine("Ingrese una cadena de texto:");
            string texto = Console.ReadLine();

            MostrarLongitud(texto);



            Console.WriteLine("ejercicio 2");
            Console.WriteLine("");
            Console.WriteLine("Ingrese un número");
            int num1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Ingrese otro número");
            int num2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Primer número: " + num1);
            Console.WriteLine("Segundo número: " + num2);

            inter(ref num1, ref num2);

            Console.WriteLine("Después del intercambio:");
            Console.WriteLine("Primer número: " + num1);
            Console.WriteLine("Segundo número: " + num2);

            Console.WriteLine("ejercicio 3");
            Console.WriteLine("");

            double precio = 48.50;
            double descuento = 0;

            Console.WriteLine("Seleccione el tipo de cliente:");
            Console.WriteLine("1. Niño");
            Console.WriteLine("2. Adulto mayor");
            Console.WriteLine("3. Premium");

            int opcion = Convert.ToInt32(Console.ReadLine());

            switch (opcion)
            {
                case 1:
                    descuento = 0.50;
                    break;
                case 2:
                    descuento = 0.30;
                    break;
                case 3:
                    descuento = 0.15;
                    break;
                default:
                    Console.WriteLine("Opción no válida");
                    return;
            }

            Console.WriteLine("Precio original: Q" + precio);

            AplicarDescuento(descuento, ref precio);

            Console.WriteLine("Precio final: Q" + precio.ToString("0.00"));
            Console.WriteLine("");

            Console.WriteLine("ejercicio 4");
            Console.WriteLine("");
            int puntosSalud = 0;
            Console.WriteLine("ingrese sus puntos de salud");
            puntosSalud = int.Parse(Console.ReadLine());

            Console.WriteLine("Estado inicial:");
            mostrarSalud(puntosSalud);

            Console.WriteLine("\nRecibiendo daño...");
            recibirDaño(ref puntosSalud);
            mostrarSalud(puntosSalud);

            Console.WriteLine("\nCurando...");
            curar(ref puntosSalud);
            mostrarSalud(puntosSalud);

            Console.WriteLine("\nCalificación final:");
            calificarDesempeño(puntosSalud);

            Console.ReadKey();
        }
        static void inter(ref int a, ref int b)
        {
            int temp = a;
            a = b;
            b = temp;
        }
        static void MostrarLongitud(string cadena)
        {
            int longitud = cadena.Length;
            Console.WriteLine("La cantidad de caracteres es: " + longitud);
        }


        static void AplicarDescuento(double porcentaje, ref double precio)
        {
            precio = precio - (precio * porcentaje);
        }

        
        static void recibirDaño(ref int puntosSalud)
        {
            puntosSalud -= 5;
            if (puntosSalud < 0)
            {
                puntosSalud = 0;
            }
        }

        
        static void curar(ref int puntosSalud)
        {
            puntosSalud += 3;
            if (puntosSalud > 15)
            {
                puntosSalud = 15;
            }
        }

        
        static void mostrarSalud(int puntosSalud)
        {
            if (puntosSalud >= 11 && puntosSalud <= 15)
            {
                Console.ForegroundColor = ConsoleColor.Green;
            }
            else if (puntosSalud >= 6)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
            }

            Console.WriteLine("Puntos de salud: " + puntosSalud);
            Console.ResetColor();
        }

       
        static void calificarDesempeño(int puntosSalud)
        {
            if (puntosSalud == 15)
            {
                Console.WriteLine("Calificación: S");
            }
            else if (puntosSalud >= 11)
            {
                Console.WriteLine("Calificación: A");
            }
            else if (puntosSalud >= 6)
            {
                Console.WriteLine("Calificación: B");
            }
            else if (puntosSalud >= 1)
            {
                Console.WriteLine("Calificación: C");
            }
            else
            {
                Console.WriteLine("Sin salud - jugador derrotado");
            }
        }
    }
}
